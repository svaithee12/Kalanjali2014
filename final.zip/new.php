<?php
//echo "this is worlingo on top";
require_once("facebook.php");

$config=array(
'appId'=> '1388619241398804',
'secret'=> 'dcad22258c837016ac4d8cc1b7c34e61',
'fileUpload'=> false,
'allowSignedRequest'=> false
);

$facebook= new Facebook($config);
$user_id= $facebook->getUser();
//echo "this is worling";
  
if($user_id)
{
    try{
     //   $user_profile =$facebook->api('/me','GET');
      //  echo "<pre>";
       // print_r($user_profile);
       // echo "</pre>";
       session_start();
	$_SESSION['user']=$user_id;
       header('Location: /register.html');
 //echo "hello world";
 
    }
    catch(FacebookApiException $e) {
        $login_url=$facebook->getLoginUrl();
        echo 'Please <a href="'.$login_url.'">login.</a>';
        error_log($e->getType());
        error_log($e->getMessage());
    }
}
else{
    $login_url= $facebook->getLoginUrl();
  //  echo 'NOT LOGGED IN Please <a href="'.$login_url.'">login.</a>';
//echo "not loggedd in";
 

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
  <title>KALANJALI 2014</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <script src="js/jquery-latest.min.js"></script> 
  <style type="text/css">
  @media (min-width: 768px){
      .class{
        height: 100%;
        width: 100%;
      }
      .wrap{
        padding-top: 13%;
        padding-bottom: 10%;
        text-align: center; 
      }
    }
  @media (max-width: 768px){
      .class{
        height: 100%;
        width: 100%;
      }
      .wrap{
        padding-top: 33%;
        padding-bottom: 10%;
        text-align: center; 
      }
    }
  </style> 
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
    <div class="center">
        <div class="wrap">
            <h3>Sign In Via</h3>
            <ul style="list-style-type: none;    padding: 0px;    margin: 0px;">
                <li><a href="<?php echo $login_url; ?> "><img src="img/fb.jpg" style="width:420px;"></a></li>
                <br>
            </ul>
        </div>
    </div>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- jQuery Version 1.11.0 -->
    <script src="js/jquery-1.11.0.js"></script>
</body>
</html>                                   