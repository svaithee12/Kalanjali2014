<?php
unset($_SESSION['name']);
session_destroy();

header('Location: login.php');

?>
<html>
    <script type='text/javascript' language='javascript'>
function DisableBackButton() {
window.history.forward()
}
DisableBackButton();
window.onload = DisableBackButton;
window.onpageshow = function(evt) { if (evt.persisted) DisableBackButton() }
window.onunload = function() { void (0) }
</script>

</html>