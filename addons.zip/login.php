<?php
session_start();
?>

<html>
    <head>
        
    </head>
    <body>
        <form method="post" action="oregister.php">
            
        <input type="text" placeholder="ENTER YOUR NAME" name="uname" required>
        <input type="submit"></input>
        
        </form>
    </body>
</html>